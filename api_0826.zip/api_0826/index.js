const express = require('express')
const server = express()
const mysql = require('mysql2')
const banco = mysql.createPool({
    user: 'root',
    password: 'thais11',
    database: "3w_2021",
    host: 'localhost',
    port: '3306'
})

server.get('/',(req, res, next) => {
    return res.status(200).send({
        mensagem: 'Servidor funcionando!'
    })
}

)

server.listen(3000, () => {
    console.log('Executando')
})